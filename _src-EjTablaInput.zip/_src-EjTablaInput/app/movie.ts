export interface Movie {
    code:number;  
    title : string;  
    director : string;  
    cast : string;  
    releaseDate : string;  
  }
